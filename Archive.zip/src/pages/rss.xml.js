import rss from "@astrojs/rss"
import { getCollection } from "astro:content"

export async function get(context) {
  const posts = await getCollection("blog", ({ data }) => {
    return !data.draft
  })

  // Sort posts by date (newest first)
  const sortedPosts = [...posts].sort((a, b) => b.data.pubDate.getTime() - a.data.pubDate.getTime())

  return rss({
    title: "Minimalist Blog",
    description: "A clean, minimalist blog about design, development, and digital experiences",
    site: context.site,
    items: sortedPosts.map((post) => ({
      title: post.data.title,
      description: post.data.description,
      pubDate: post.data.pubDate,
      link: `/blog/${post.slug}`,
    })),
  })
}

