/// <reference path="../.astro/types.d.ts" />
// Ensure we have the proper type definitions for content collections
/// <reference types="astro/client" />
/// <reference types="astro/content" />

