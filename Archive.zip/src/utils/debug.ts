export function debugObject(obj: any): string {
  return JSON.stringify(obj, null, 2)
}

